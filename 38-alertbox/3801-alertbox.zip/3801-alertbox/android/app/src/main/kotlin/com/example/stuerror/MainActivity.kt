package com.example.stuerror

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
